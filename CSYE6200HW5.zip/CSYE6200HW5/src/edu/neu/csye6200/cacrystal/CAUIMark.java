/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.csye6200.cacrystal;

import edu.neu.csye6200.ui.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author tim
 */
public class CAUIMark extends CAApp {

    private boolean suspended;
    private Thread thread = null;
    private JFrame frame1 = null;
    private JPanel mainPanel = null;
    private JButton butn0 = null;
    private JButton butn1 = null;
    private JButton butn2 = null;
    private JButton butn3 = null;
    private JButton butn4 = null;
    private int inputCount = 0;
    private int rulenum = 0;
    private JLabel getCtnLabel = null;
    private JTextField stepCntF = null;
    private JComboBox<String> ruleBox = null;
    private CAFlakeSet cafs = new CAFlakeSet();
    private CACanvas canvas = null;//my display pannel
    private CAFlake caf0 = new CAFlake();

    public CAUIMark() {
        initialization();
        System.out.println("construction done");
    }

    public void initialization() {
        System.out.println("initgui in cauimark");
        frame1 = new JFrame();
        frame1.setTitle("Snow Flake Generate Application");
        frame1.setSize(new Dimension(400, 300));
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setLayout(new BorderLayout());
        mainPanel = getNorthPanel();
        frame1.add(mainPanel, BorderLayout.NORTH);
        frame1.setVisible(true);
        frame1.setResizable(false);
        frame1.setSize(790, 850);
    }

    @Override
    public JPanel getNorthPanel() {
        System.out.println("caguimark getnorthpanel");
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        butn0 = new JButton("Start");
        butn1 = new JButton("Pause");
        butn2 = new JButton("Continue");
        butn3 = new JButton("Stop");
        butn4 = new JButton("Close");
        butn1.setEnabled(false);
        butn2.setEnabled(false);
        butn3.setEnabled(false);
        butn0.addActionListener(this);
        butn1.addActionListener(this);
        butn2.addActionListener(this);
        butn3.addActionListener(this);
        butn4.addActionListener(this);
        panel.add(butn0);
        panel.add(butn1);
        panel.add(butn2);
        panel.add(butn3);
        panel.add(butn4);
        getCtnLabel = new JLabel("Gemeration Times");
        panel.add(getCtnLabel);
        stepCntF = new JTextField("30");
        panel.add(stepCntF);
        ruleBox = new JComboBox<String>();
        ruleBox.addItem("rule");
        ruleBox.addItem("Rule 1");
        ruleBox.addItem("Rule 2");
        ruleBox.addItem("Rule 3");
        ruleBox.addActionListener(this);
        System.out.println("you have added ruleBox to listner");
        panel.add(ruleBox);
        panel.setBackground(Color.LIGHT_GRAY);
        return panel;
    }

    public synchronized void mysuspend() {
        suspended = true;
    }

    public synchronized void myresume() {
        suspended = false;
        notify();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Start") || e.getActionCommand().equals("Restart")) {
            System.out.println("you click start");
            if (rulenum == 0) {
                JOptionPane.showMessageDialog(null, "You must select a rule  for generate Flake Cell!", "ERROR",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                butn0.setEnabled(false);
                butn1.setEnabled(true);
                butn2.setEnabled(true);
                butn3.setEnabled(true);

                if (butn0.getText() == "Start") {
                    butn0.setText("Restart");
                }
                inputCount = Integer.parseInt(stepCntF.getText());
                System.out.println("thread start");

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {

                        int counter = 0;
                        while (counter < inputCount) {
                            try {
                                System.out.println("canvas repaint");
                                canvas.setCnt(counter);
                                canvas.repaint();
                                System.out.println(counter);

//                                synchronized (this) {
//                                    while (suspended) {
//                                        wait();
//
//                                    }
//                                }

                                Thread.sleep(200);
                            } catch (InterruptedException e) {
                                return;
                            }
                            counter++;
                            if (counter == inputCount) {
                                butn0.setEnabled(true);
                            }
                        }
                        System.out.println("Thread End");
                    }

                };
                thread = new Thread(runnable);
                thread.start();
            }

        }

        if (e.getActionCommand().equals("Pause")) {
            System.out.println("you click pause");
            thread.suspend();
//            mysuspend();
        }
        if (e.getActionCommand().equals("Continue")) {
            System.out.println("you click continue");
            thread.resume();
//            myresume();

        }
        if (e.getActionCommand().equals("Stop")) {
            System.out.println("you click stop");
//            thread.stop();
            thread.interrupt();
            butn0.setEnabled(true);
            int command = ruleBox.getSelectedIndex();
            switch (command) {
                case 1: {
                    if (butn0.getText() == "Restart") {
                        butn0.setText("Start");
                    }
                    System.out.println("rule 1 selected");
                    rulenum = 1;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate1(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame1.add(canvas, BorderLayout.CENTER);
                    frame1.setVisible(true);
                }
                break;
                case 2: {
                    if (butn0.getText() == "Restart") {
                        butn0.setText("Start");
                    }
                    System.out.println("rule 2 selected");
                    rulenum = 2;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate2(cafs, caf0, k);
                    }

                    canvas = new CACanvas(cafs);

                    frame1.add(canvas, BorderLayout.CENTER);
                    frame1.setVisible(true);
                }
                break;
                case 3: {
                    if (butn0.getText() == "Restart") {
                        butn0.setText("Start");
                    }
                    System.out.println("rule 3 selected");
                    rulenum = 3;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate3(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);

                    frame1.add(canvas, BorderLayout.CENTER);
                    frame1.setVisible(true);
                }
                break;
            }

        }
        if (e.getActionCommand().equals("Close")) {
            System.out.println("you click close");
            frame1.setVisible(false);
            System.exit(0);
        }
        if (e.getSource() == ruleBox) {
            System.out.println("you click ruleBox");
            int command = ruleBox.getSelectedIndex();
            switch (command) {
                case 1: {
                    System.out.println("rule1 selected");
                    if (butn0.getText() == "Restart") {
                        butn0.setText("Start");
                    }
                    System.out.println("rule 1 selected");
                    rulenum = 1;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate1(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame1.add(canvas, BorderLayout.CENTER);
                    frame1.setVisible(true);
                }
                break;
                case 2: {

                    if (butn0.getText() == "Restart") {
                        butn0.setText("Start");
                    }
                    System.out.println("rule 2 selected");
                    rulenum = 2;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate2(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame1.add(canvas, BorderLayout.CENTER);
                    frame1.setVisible(true);
                }
                break;
                case 3: {

                    if (butn0.getText() == "Restart") {
                        butn0.setText("Start");
                    }
                    System.out.println("rule 3 selected");
                    rulenum = 3;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate3(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame1.add(canvas, BorderLayout.CENTER);
                    frame1.setVisible(true);
                }
                break;
            }
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowClosing(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowClosed(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowIconified(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowActivated(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
