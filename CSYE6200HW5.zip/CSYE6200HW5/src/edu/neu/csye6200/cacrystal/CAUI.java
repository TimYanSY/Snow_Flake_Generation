/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.csye6200.cacrystal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author tim
 */
public class CAUI implements ActionListener {

    private Thread thread = null;

    private JFrame frame = null;
    private JPanel mainPanel = null;
    private JButton butn0 = null;
    private JButton butn1 = null;
    private JButton butn2 = null;
    private JButton butn3 = null;
    private JButton butn4 = null;
    private int inputCount = 0;
    private int rulenum = 0;

    private JLabel getCtnLabel = new JLabel("GetCount");
    private JTextField stepCntF = null;
    private JComboBox<String> ruleBox = null;
    private CAFlakeSet cafs = new CAFlakeSet();

    private CACanvas canvas = null;//my display pannel
    private CAFlake caf0 = new CAFlake();

    public CAUI() {
        initGUI();
        System.out.println("Construction done");
    }

    private void initGUI() {
        frame = new JFrame();
        frame.setTitle("Snow Flake Generate Application");
        frame.setSize(new Dimension(400, 300));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        mainPanel = getMainPannel();
        frame.add(mainPanel, BorderLayout.NORTH);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.setSize(790, 850);
    }

    public JPanel getMainPannel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        butn0 = new JButton("Start");
        butn1 = new JButton("Pause");
        butn2 = new JButton("Continue");
        butn3 = new JButton("Stop");
        butn4 = new JButton("Close");
        butn0.addActionListener(this);
        butn1.addActionListener(this);
        butn2.addActionListener(this);
        butn3.addActionListener(this);
        butn4.addActionListener(this);
        panel.add(butn0);
        panel.add(butn1);
        panel.add(butn2);
        panel.add(butn3);
        panel.add(butn4);
        panel.add(getCtnLabel);
        stepCntF = new JTextField("10");
        panel.add(stepCntF);
        ruleBox = new JComboBox<String>();
        ruleBox.addItem("<--select a rule below-->");

        ruleBox.addItem("Rule 1");
        ruleBox.addItem("Rule 2");
        ruleBox.addItem("Rule 3");
        ruleBox.addActionListener(this);
        panel.add(ruleBox);
        panel.setBackground(Color.red);
        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Start")) {
            if (rulenum == 0) {
                JOptionPane.showMessageDialog(null, "You must select a rule for generate Flake Cell!", "ERROR",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                inputCount = Integer.parseInt(stepCntF.getText());
                System.out.println("thread start");
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {

                        int counter = 0;
                        while (counter < inputCount) {
                            System.out.println("canvas repaint");
                            canvas.setCnt(counter);
                            canvas.repaint();
                            System.out.println(counter);
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            counter++;
                        }
                        System.out.println("Thread End");
                    }

                };
                thread = new Thread(runnable);
                thread.start();
            }
        }

        if (e.getActionCommand().equals("Pause")) {
            thread.suspend();
        }
        if (e.getActionCommand().equals("Continue")) {
            thread.resume();
        }
        if (e.getActionCommand().equals("Stop")) {
            thread.stop();
        }
        if (e.getActionCommand().equals("Close")) {
            frame.setVisible(false);
            System.exit(0);
        }
        if (e.getSource() == ruleBox) {
            int command = ruleBox.getSelectedIndex();
            switch (command) {
                case 1: {
                    System.out.println("rule 1 selected");
                    rulenum = 1;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate1(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame.add(canvas, BorderLayout.CENTER);
                    frame.setVisible(true);
                }
                break;
                case 2: {
                    System.out.println("rule 2 selected");
                    rulenum = 2;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate2(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame.add(canvas, BorderLayout.CENTER);
                    frame.setVisible(true);
                }
                break;
                case 3: {
                    System.out.println("rule 3 selected");
                    rulenum = 3;
                    System.out.println("rulenum is " + rulenum);
                    cafs = new CAFlakeSet();
                    caf0.getCell(0, 0).setColor("■");
                    cafs.addFlake(caf0);
                    for (int k = 1; k < 100; k++) {
                        CAFlakeSet.generate3(cafs, caf0, k);
                    }
                    canvas = new CACanvas(cafs);
                    frame.add(canvas, BorderLayout.CENTER);
                    frame.setVisible(true);
                }
                break;
            }
        }
    }
}
