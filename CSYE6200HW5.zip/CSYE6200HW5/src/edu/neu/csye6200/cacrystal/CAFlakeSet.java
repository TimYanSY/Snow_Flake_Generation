/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.csye6200.cacrystal;

import java.util.*;

/**
 *
 * @author tim
 */
public class CAFlakeSet {

    private ArrayList flakeList = new ArrayList();
    private static int num = 0;

    public static void generate1(CAFlakeSet cafset, CAFlake cafs, int k) {
        CAFlake caftmp = new CAFlake();
        for (int i = -32; i <= 32; i++) {
            for (int j = -32; j <= 32; j++) {
                CAFlakeRules.setCellColor1(cafset.getCAFlake(k - 1), caftmp.getCell(i, j));
            }
        }
        cafset.addFlake(caftmp);
    }

    public static void generate2(CAFlakeSet cafset, CAFlake cafs, int k) {
        CAFlake caftmp = new CAFlake();
        for (int i = -32; i <= 32; i++) {
            for (int j = -32; j <= 32; j++) {
                CAFlakeRules.setCellColor2(cafset.getCAFlake(k - 1), caftmp.getCell(i, j));
            }
        }
        cafset.addFlake(caftmp);
    }

    public static void generate3(CAFlakeSet cafset, CAFlake cafs, int k) {
        CAFlake caftmp = new CAFlake();
        for (int i = -32; i <= 32; i++) {
            for (int j = -32; j <= 32; j++) {
                CAFlakeRules.setCellColor3(cafset.getCAFlake(k - 1), caftmp.getCell(i, j));
            }
        }
        cafset.addFlake(caftmp);
    }

    public CAFlake getCAFlake(int i) {
        return (CAFlake) flakeList.get(i);
    }

    public ArrayList getFlakeList() {
        return flakeList;
    }

    public static int getNum() {
        return num;
    }

    public void setFlakeList(ArrayList flakeList) {
        this.flakeList = flakeList;
    }

    public void addFlake(CAFlake caf) {
        flakeList.add(caf);
        num++;
    }

}
