package edu.neu.csye6200.cacrystal;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author tim
 */
public class CACanvas extends JPanel {

    CAFlakeSet cafs = new CAFlakeSet();
    private  int cnt=0;

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    //JPanel drawable region
    public CACanvas(CAFlakeSet cafs) {
        this.cafs = cafs;
    }

    public void paint(Graphics g) {
        drawCanvas(g);
    }


    public void drawCanvas(Graphics g) {
        
        CAFlake caf = cafs.getCAFlake(cnt);

        Graphics2D g2d = (Graphics2D) g;

        Dimension size = getSize();
        g2d.setColor(Color.BLACK);
        

        g2d.fillRect(0, 0, size.width, size.height);

        int cellSize = 10;

        for (int i = -32; i <= 32; i++) {
            for (int j = -32; j <= 32; j++) {
                CAFlakeCell cafc = caf.getCell(j, i);

                int x=i+32;
                int y=j+32;
                if (cafc.getColor() == "□") {
                    Color col = Color.CYAN;
                    paintCell(g2d, x * (cellSize + 2), y * (cellSize + 2), cellSize, col);
                } else {
                    Color col = Color.WHITE;
                    paintCell(g2d, x * (cellSize + 2), y * (cellSize + 2), cellSize, col);
                }
            }
        }

    }

    // single 
    private void paintCell(Graphics2D g2d, int x, int y, int size, Color color) {
        g2d.setColor(color);
        g2d.fillRect(x, y, size, size);
    }

}
