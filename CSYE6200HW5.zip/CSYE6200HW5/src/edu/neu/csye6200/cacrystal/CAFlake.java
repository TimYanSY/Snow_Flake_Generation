/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.csye6200.cacrystal;

/**
 *
 * @author tim
 */
public class CAFlake {

    private CAFlakeCell[][] flake = new CAFlakeCell[65][65];

    public CAFlake() {
        flake = new CAFlakeCell[65][65];
        for (int i = 0; i < 65; i++) {
            for (int j = 0; j < 65; j++) {
                CAFlakeCell cafc = new CAFlakeCell();
                cafc.setColor("□");
                cafc.setX(i - 32);
                cafc.setY(j - 32);
                flake[i][j] = cafc;
            }
        }
    }

    public CAFlakeCell[][] getFlake() {
        return flake;
    }

    public void setFlake(CAFlakeCell[][] flake) {
        this.flake = flake;
    }

    public CAFlakeCell getCell(int x, int y) {
        return flake[32 + x][32 + y];
        
    }

    public void display() {
        for (int i = -32; i <= 32; i++) {
            for (int j = -32; j < 32; j++) {
                System.out.print(flake[32 + i][32 + j].getColor()+" ");
            }
            System.out.println();
        }
        System.out.println("display end");
    }
}
