/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.csye6200.cacrystal;

/**
 *
 * @author tim
 */
public class CAFlakeRules {

    private int num;

    public static void setCellColor1(CAFlake caf, CAFlakeCell cafc) {

        int num = 0;
        int x = cafc.getX();
        int y = cafc.getY();

        if (caf.getCell(x, y).getColor() == "■") {
            cafc.setColor("■");
        } else {
            //up
            if ((x - 1) >= -32) {
                if (caf.getCell(x - 1, y).getColor() == "■") {
                    num++;
                }
            }

            //down
            if (x + 1 <= 32) {
                if (caf.getCell(x + 1, y).getColor() == "■") {
                    num++;
                }
            }
            //left
            if (y - 1 >= -32) {
                if (caf.getCell(x, y - 1).getColor() == "■") {
                    num++;
                }
            }

            //right
            if (y + 1 <= 32) {
                if (caf.getCell(x, y + 1).getColor() == "■") {
                    num++;
                }
            }

            if (num % 2 == 1) {
                cafc.setColor("■");
            }
        }
        cafc.setAround(num);
    }

    public static void setCellColor2(CAFlake caf, CAFlakeCell cafc) {

        int num = 0;
        int x = cafc.getX();
        int y = cafc.getY();

        if (caf.getCell(x, y).getColor() == "■") {
            cafc.setColor("■");
        } else {
            //up
            if ((x - 1) >= -32) {
                if (caf.getCell(x - 1, y).getColor() == "■") {
                    num++;
                }
            }
            //down
            if (x + 1 <= 32) {
                if (caf.getCell(x + 1, y).getColor() == "■") {
                    num++;
                }
            }
            //left
            if (y - 1 >= -32) {
                if (caf.getCell(x, y - 1).getColor() == "■") {
                    num++;
                }
            }

            //right
            if (y + 1 <= 32) {
                if (caf.getCell(x, y + 1).getColor() == "■") {
                    num++;
                }
            }
            //up and left
            if ((x - 1 >= -32) && (y - 1 >= -32)) {
                if (caf.getCell(x - 1, y - 1).getColor() == "■") {
                    num++;
                }
            }
            //up and right
            if ((x - 1) >= -32 && (y + 1 <= 32)) {
                if (caf.getCell(x - 1, y + 1).getColor() == "■") {
                    num++;
                }
            }
            //down and left
            if ((x + 1 <= 32) && (y - 1 >= -32)) {
                if (caf.getCell(x + 1, y - 1).getColor() == "■") {
                    num++;
                }

            }
            //down and right
            if ((x + 1 <= 32) && (y + 1 <= 32)) {
                if (caf.getCell(x + 1, y + 1).getColor() == "■") {
                    num++;
                }
            }
            if (num == 1) {
                cafc.setColor("■");
            }
        }
    }

    public static void setCellColor3(CAFlake caf, CAFlakeCell cafc) {

        int num = 0;
        int x = cafc.getX();
        int y = cafc.getY();

        if (caf.getCell(x, y).getColor() == "■") {
            cafc.setColor("■");
        } else {
            //up
            if ((x - 1) >= -32) {
                if (caf.getCell(x - 1, y).getColor() == "■") {
                    num++;
                }
            }
            //down
            if (x + 1 <= 32) {
                if (caf.getCell(x + 1, y).getColor() == "■") {
                    num++;
                }
            }
            //left
            if (y - 1 >= -32) {
                if (caf.getCell(x, y - 1).getColor() == "■") {
                    num++;
                }
            }

            //right
            if (y + 1 <= 32) {
                if (caf.getCell(x, y + 1).getColor() == "■") {
                    num++;
                }
            }
            //up and left
            if ((x - 1 >= -32) && (y - 1 >= -32)) {
                if (caf.getCell(x - 1, y - 1).getColor() == "■") {
                    num++;
                }
            }
            //up and right
            if ((x - 1) >= -32 && (y + 1 <= 32)) {
                if (caf.getCell(x - 1, y + 1).getColor() == "■") {
                    num++;
                }
            }
            //down and left
            if ((x + 1 <= 32) && (y - 1 >= -32)) {
                if (caf.getCell(x + 1, y - 1).getColor() == "■") {
                    num++;
                }

            }
            //down and right
            if ((x + 1 <= 32) && (y + 1 <= 32)) {
                if (caf.getCell(x + 1, y + 1).getColor() == "■") {
                    num++;
                }
            }
//            if (num % 2 == 1) {
//                cafc.setColor("■");
//            }
            if (num == 1 || num ==2) {
                cafc.setColor("■");
            }
        }
    }

}
